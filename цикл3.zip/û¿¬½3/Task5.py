width = int(input("Введите ширину: "))
height = int(input("Введите высоту: "))

for _ in range(height):
    print("*" * width)