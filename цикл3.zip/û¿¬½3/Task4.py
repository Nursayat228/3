pos = 0
neg = 0
zero = 0

for _ in range(10):
    num = int(input("Введите число: "))
    if num > 0:
        pos += 1
    elif num < 0:
        neg += 1
    else:
        zero += 1

print("Положительных:", pos)
print("Отрицательных:", neg)
print("Нулей:", zero)