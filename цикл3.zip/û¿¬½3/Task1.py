N = int(input("Введите число N: "))

print(f"Числа от 1 до {N}, кратные трём:")
for i in range(1, N + 1):
    if i % 3 == 0:
        print(i, end=" ")
print()