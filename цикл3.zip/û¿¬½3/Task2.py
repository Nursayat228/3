total_sum = 0

for i in range(1, 101, 2):
    total_sum += i

print(f"Сумма всех нечётных чисел от 1 до 100 равна: {total_sum}")