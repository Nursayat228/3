A = float(input("Введите число A: "))
N = int(input("Введите целую положительную степень N: "))

result = 1
for _ in range(N):
    result *= A

print(f"{A} в степени {N} равно: {result}")